/*
 *  ECSE 321
 *
 *  Ying Han Wang   260588337
 *  Andrew Lin      260586060
 */

package ca.mcgill.ecse321.eventregistration;

import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import ca.mcgill.ecse321.eventregistration.application.EventRegistration;
import ca.mcgill.ecse321.eventregistration.controller.EventRegistrationController;
import ca.mcgill.ecse321.eventregistration.controller.InvalidInputException;
import ca.mcgill.ecse321.eventregistration.model.Participant;
import ca.mcgill.ecse321.eventregistration.model.Event;
import ca.mcgill.ecse321.eventregistration.model.Registration;
import ca.mcgill.ecse321.eventregistration.model.RegistrationManager;

public class MainActivity extends AppCompatActivity {
    RegistrationManager rm = RegistrationManager.getInstance();
    HashMap<Integer, Participant> participants;
    HashMap<Integer, Event> events;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("dd-MM-yyyy");
        TextView newevent_date = (TextView)findViewById(R.id.newevent_date);
        String date = mdformat.format(calendar.getTime());
        newevent_date.setText(date);

        Date dt = new Date();
        int hours = dt.getHours();
        int delayedhour = dt.getHours() + 1;
        int minutes = dt.getMinutes();
        String curTime = hours + ":" + minutes;
        String DelayedTime = delayedhour + ":" + minutes;
        TextView newevent_time_begin = (TextView)findViewById(R.id.newevent_time_begin);
        newevent_time_begin.setText(curTime);
        TextView newevent_time_end = (TextView)findViewById(R.id.newevent_time_end);
        newevent_time_end.setText(DelayedTime);

        /*
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        */

        refreshData();
    }

    private void refreshData() {
        TextView tv1 = (TextView) findViewById(R.id.newparticipant_name);
        tv1.setText("");
        TextView tv2 = (TextView) findViewById(R.id.newevent_name);
        tv2.setText("");

        // Initialize the data in the participant spinner
        Spinner spinner = (Spinner) findViewById(R.id.participantspinner);
        ArrayAdapter<CharSequence> participantAdapter = new
                ArrayAdapter<CharSequence>(this, android.R.layout.simple_spinner_item);
        participantAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        this.participants = new HashMap<Integer, Participant>();

        int i = 0;
        for (Iterator<Participant> participants = rm.getParticipants().iterator();
             participants.hasNext(); i++) {
            Participant p = participants.next();
            participantAdapter.add(p.getName());
            this.participants.put(i, p);
        }
        spinner.setAdapter(participantAdapter);

        // Initialize the data in the event spinner
        Spinner spinner2 = (Spinner) findViewById(R.id.eventspinner);
        ArrayAdapter<CharSequence> eventAdapter = new
                ArrayAdapter<CharSequence>(this, android.R.layout.simple_spinner_item);
        eventAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        this.events = new HashMap<Integer, Event>();

        int j = 0;
        for (Iterator<Event> events = rm.getEvents().iterator();
             events.hasNext(); j++) {
            Event e = events.next();
            eventAdapter.add(e.getName());
            this.events.put(j, e);
        }
        spinner2.setAdapter(eventAdapter);
    }

    public void addParticipant(View v) {
        TextView tv = (TextView) findViewById(R.id.newparticipant_name);
        EventRegistrationController pc = new EventRegistrationController();

        TextView errorTextView = (TextView)findViewById(R.id.error);

        try {
            pc.createParticipant(tv.getText().toString());
            errorTextView.setText("");
        } catch (InvalidInputException e) {
            errorTextView.setText("Participant name cannot be empty!");
        }

        refreshData();
    }

    public void addEvent(View v) {
        TextView tv = (TextView) findViewById(R.id.newevent_name);
        java.sql.Date d1 = new java.sql.Date(R.id.newevent_date);
        java.sql.Time t1 = new java.sql.Time(R.id.newevent_time_begin);
        java.sql.Time t2 = new java.sql.Time(R.id.newevent_time_end);
        EventRegistrationController pc = new EventRegistrationController();
        TextView errorTextView = (TextView)findViewById(R.id.error);

        if(R.id.newevent_time_begin > R.id.newevent_time_end){
            errorTextView.setText("Event end time cannot be before event start time!");
            refreshData();
        } else {
            try {
                pc.createEvent(tv.getText().toString(), d1, t1, t2);
                errorTextView.setText("");
            } catch (InvalidInputException e) {
                errorTextView.setText("Event name cannot be empty!");
            }
        }

        refreshData();
    }

    public void addRegister(View v) {
        EventRegistrationController erc  = new EventRegistrationController();
        TextView errorTextView = (TextView)findViewById(R.id.error);
        Participant p = null;
        Event e = null;

        Spinner pSpinner = (Spinner) findViewById(R.id.participantspinner);
        String particip = pSpinner.getSelectedItem().toString();
        Spinner eSpinner = (Spinner) findViewById(R.id.eventspinner);
        String eve = eSpinner.getSelectedItem().toString();

        List<Participant> pList = new ArrayList<Participant>();
        List<Event> eList = new ArrayList<Event>();

        pList = rm.getParticipants();
        eList = rm.getEvents();

        Toast.makeText(getApplicationContext(), particip + " " +  eve, Toast.LENGTH_LONG).show();

        for (int i = 0; i < pList.size(); i++) {
            if (particip.equals(pList.get(i).getName())) {
                p = pList.get(i);
                break;
            }
        }

        for (int i = 0; i < eList.size(); i++) {
            if (eve.equals(eList.get(i).getName())) {
                e = eList.get(i);
                break;
            }
        }

        try {
            erc.register(p, e);
            errorTextView.setText("");
        } catch (InvalidInputException er) {
            errorTextView.setText("Registration field cannot be empty!");
        }

        refreshData();
    }

    public void showDatePickerDialog(View v) {
        TextView tf = (TextView) v;
        Bundle args = getDateFromLabel(tf.getText());
        args.putInt("id", v.getId());

        DatePickerFragment newFragment = new DatePickerFragment();
        newFragment.setArguments(args);
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }


    public void showTimePickerDialog(View v) {
        TextView tf = (TextView) v;
        Bundle args = getTimeFromLabel(tf.getText());
        args.putInt("id", v.getId());

        TimePickerFragment newFragment = new TimePickerFragment();
        newFragment.setArguments(args);
        newFragment.show(getSupportFragmentManager(), "TimePicker");
    }

    private Bundle getTimeFromLabel(CharSequence text) {
        Bundle rtn = new Bundle();
        String comps[] = text.toString().split(":");
        int hour = 12;
        int minute = 0;

        if (comps.length == 2) {
            hour = Integer.parseInt(comps[0]);
            minute = Integer.parseInt(comps[1]);
        }

        rtn.putInt("hour", hour);
        rtn.putInt("minute", minute);

        return rtn;
    }

    private Bundle getDateFromLabel(CharSequence text) {
        Bundle rtn = new Bundle();
        String comps[] = text.toString().split("-");
        int day = 1;
        int month = 1;
        int year = 1;

        if (comps.length == 3) {
            day = Integer.parseInt(comps[0]);
            month = Integer.parseInt(comps[1]);
            year = Integer.parseInt(comps[2]);
        }

        rtn.putInt("day", day);
        rtn.putInt("month", month-1);
        rtn.putInt("year", year);

        return rtn;
    }

    public void setTime(int id, int h, int m) {

        TextView tv = (TextView) findViewById(id);
        tv.setText(String.format("%02d:%02d", h, m));
    }

    public void setDate(int id, int d, int m, int y) {
        TextView tv = (TextView) findViewById(id);
        tv.setText(String.format("%02d-%02d-%04d", d, m + 1, y));
    }
}
