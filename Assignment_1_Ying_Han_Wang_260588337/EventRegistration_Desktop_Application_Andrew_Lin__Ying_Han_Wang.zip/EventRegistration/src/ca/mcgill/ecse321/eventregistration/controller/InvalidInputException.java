// Andrew Lin	260586060
// Ying Han Wang 260588337
package ca.mcgill.ecse321.eventregistration.controller;

public class InvalidInputException extends Exception {
	
	private static final long serialVersionUID = -5633915762803837868L;
	
	public InvalidInputException(String errorMessage)
	{
		super(errorMessage);
	}
}
