<?php
// Andrew Lin	260586060
// Ying Han Wang 260588337
class InputValidator
{
	public static function validate_input($data)
	{
		$data = trim($data);	
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
}
?>