<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.24.0-d60c319 modeling language!*/

class Person
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Person Attributes
  private $name;

  //Person Associations
  private $ticket;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public function __construct($aName = null, $aTicket = null)
  {
    if (func_num_args() == 0) { return; }

    $this->name = $aName;
    if ($aTicket == null || $aTicket->getPerson() != null)
    {
      throw new Exception("Unable to create Person due to aTicket");
    }
    $this->ticket = $aTicket;
  }
  public static function newInstance($aName, $aTripForTicket, $aCabinForTicket)
  {
    $thisInstance = new Person();
    $thisInstance->name = $aName;
    $thisInstance->ticket = new Ticket($thisInstance, $aTripForTicket, $aCabinForTicket);
    return $thisInstance;
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function setName($aName)
  {
    $wasSet = false;
    $this->name = $aName;
    $wasSet = true;
    return $wasSet;
  }

  public function getName()
  {
    return $this->name;
  }

  public function getTicket()
  {
    return $this->ticket;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {
    $existingTicket = $this->ticket;
    $this->ticket = null;
    if ($existingTicket != null)
    {
      $existingTicket->delete();
    }
  }

}
?>