<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.24.0-d60c319 modeling language!*/

class Transaction
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Transaction Attributes
  private $creditCardToBill;
  private $authorizationCode;
  private $successful;

  //Transaction Associations
  private $tickets;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public function __construct($aCreditCardToBill, $aAuthorizationCode, $aSuccessful)
  {
    $this->creditCardToBill = $aCreditCardToBill;
    $this->authorizationCode = $aAuthorizationCode;
    $this->successful = $aSuccessful;
    $this->tickets = array();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function setCreditCardToBill($aCreditCardToBill)
  {
    $wasSet = false;
    $this->creditCardToBill = $aCreditCardToBill;
    $wasSet = true;
    return $wasSet;
  }

  public function setAuthorizationCode($aAuthorizationCode)
  {
    $wasSet = false;
    $this->authorizationCode = $aAuthorizationCode;
    $wasSet = true;
    return $wasSet;
  }

  public function setSuccessful($aSuccessful)
  {
    $wasSet = false;
    $this->successful = $aSuccessful;
    $wasSet = true;
    return $wasSet;
  }

  public function getCreditCardToBill()
  {
    return $this->creditCardToBill;
  }

  public function getAuthorizationCode()
  {
    return $this->authorizationCode;
  }

  public function getSuccessful()
  {
    return $this->successful;
  }

  public function getTicket_index($index)
  {
    $aTicket = $this->tickets[$index];
    return $aTicket;
  }

  public function getTickets()
  {
    $newTickets = $this->tickets;
    return $newTickets;
  }

  public function numberOfTickets()
  {
    $number = count($this->tickets);
    return $number;
  }

  public function hasTickets()
  {
    $has = $this->numberOfTickets() > 0;
    return $has;
  }

  public function indexOfTicket($aTicket)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->tickets as $ticket)
    {
      if ($ticket->equals($aTicket))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public static function minimumNumberOfTickets()
  {
    return 0;
  }

  public function addTicket($aTicket)
  {
    $wasAdded = false;
    if ($this->indexOfTicket($aTicket) !== -1) { return false; }
    $this->tickets[] = $aTicket;
    $wasAdded = true;
    return $wasAdded;
  }

  public function removeTicket($aTicket)
  {
    $wasRemoved = false;
    if ($this->indexOfTicket($aTicket) != -1)
    {
      unset($this->tickets[$this->indexOfTicket($aTicket)]);
      $this->tickets = array_values($this->tickets);
      $wasRemoved = true;
    }
    return $wasRemoved;
  }

  public function addTicketAt($aTicket, $index)
  {  
    $wasAdded = false;
    if($this->addTicket($aTicket))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfTickets()) { $index = $this->numberOfTickets() - 1; }
      array_splice($this->tickets, $this->indexOfTicket($aTicket), 1);
      array_splice($this->tickets, $index, 0, array($aTicket));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveTicketAt($aTicket, $index)
  {
    $wasAdded = false;
    if($this->indexOfTicket($aTicket) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfTickets()) { $index = $this->numberOfTickets() - 1; }
      array_splice($this->tickets, $this->indexOfTicket($aTicket), 1);
      array_splice($this->tickets, $index, 0, array($aTicket));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addTicketAt($aTicket, $index);
    }
    return $wasAdded;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {
    $this->tickets = array();
  }

}
?>