<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.24.0-d60c319 modeling language!*/

class Destination
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Destination Attributes
  private $name;

  //Destination Associations
  private $availableTrips;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public function __construct($aName)
  {
    $this->name = $aName;
    $this->availableTrips = array();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function setName($aName)
  {
    $wasSet = false;
    $this->name = $aName;
    $wasSet = true;
    return $wasSet;
  }

  public function getName()
  {
    return $this->name;
  }

  public function getAvailableTrip_index($index)
  {
    $aAvailableTrip = $this->availableTrips[$index];
    return $aAvailableTrip;
  }

  public function getAvailableTrips()
  {
    $newAvailableTrips = $this->availableTrips;
    return $newAvailableTrips;
  }

  public function numberOfAvailableTrips()
  {
    $number = count($this->availableTrips);
    return $number;
  }

  public function hasAvailableTrips()
  {
    $has = $this->numberOfAvailableTrips() > 0;
    return $has;
  }

  public function indexOfAvailableTrip($aAvailableTrip)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->availableTrips as $availableTrip)
    {
      if ($availableTrip->equals($aAvailableTrip))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public static function minimumNumberOfAvailableTrips()
  {
    return 0;
  }

  public function addAvailableTripVia($aDepartureTime, $aArrivalTime, $aTripDuration)
  {
    return new Trip($aDepartureTime, $aArrivalTime, $aTripDuration, $this);
  }

  public function addAvailableTrip($aAvailableTrip)
  {
    $wasAdded = false;
    if ($this->indexOfAvailableTrip($aAvailableTrip) !== -1) { return false; }
    $existingDestination = $aAvailableTrip->getDestination();
    $isNewDestination = $existingDestination != null && $this !== $existingDestination;
    if ($isNewDestination)
    {
      $aAvailableTrip->setDestination($this);
    }
    else
    {
      $this->availableTrips[] = $aAvailableTrip;
    }
    $wasAdded = true;
    return $wasAdded;
  }

  public function removeAvailableTrip($aAvailableTrip)
  {
    $wasRemoved = false;
    //Unable to remove aAvailableTrip, as it must always have a destination
    if ($this !== $aAvailableTrip->getDestination())
    {
      unset($this->availableTrips[$this->indexOfAvailableTrip($aAvailableTrip)]);
      $this->availableTrips = array_values($this->availableTrips);
      $wasRemoved = true;
    }
    return $wasRemoved;
  }

  public function addAvailableTripAt($aAvailableTrip, $index)
  {  
    $wasAdded = false;
    if($this->addAvailableTrip($aAvailableTrip))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfAvailableTrips()) { $index = $this->numberOfAvailableTrips() - 1; }
      array_splice($this->availableTrips, $this->indexOfAvailableTrip($aAvailableTrip), 1);
      array_splice($this->availableTrips, $index, 0, array($aAvailableTrip));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveAvailableTripAt($aAvailableTrip, $index)
  {
    $wasAdded = false;
    if($this->indexOfAvailableTrip($aAvailableTrip) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfAvailableTrips()) { $index = $this->numberOfAvailableTrips() - 1; }
      array_splice($this->availableTrips, $this->indexOfAvailableTrip($aAvailableTrip), 1);
      array_splice($this->availableTrips, $index, 0, array($aAvailableTrip));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addAvailableTripAt($aAvailableTrip, $index);
    }
    return $wasAdded;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {
    foreach ($this->availableTrips as $aAvailableTrip)
    {
      $aAvailableTrip->delete();
    }
  }

}
?>