<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.24.0-d60c319 modeling language!*/

class Trip
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Trip Attributes
  private $departureTime;
  private $arrivalTime;
  private $tripDuration;

  //Trip Associations
  private $availableCabins;
  private $destination;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public function __construct($aDepartureTime, $aArrivalTime, $aTripDuration, $aDestination)
  {
    $this->departureTime = $aDepartureTime;
    $this->arrivalTime = $aArrivalTime;
    $this->tripDuration = $aTripDuration;
    $this->availableCabins = array();
    $didAddDestination = $this->setDestination($aDestination);
    if (!$didAddDestination)
    {
      throw new Exception("Unable to create availableTrip due to destination");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function setDepartureTime($aDepartureTime)
  {
    $wasSet = false;
    $this->departureTime = $aDepartureTime;
    $wasSet = true;
    return $wasSet;
  }

  public function setArrivalTime($aArrivalTime)
  {
    $wasSet = false;
    $this->arrivalTime = $aArrivalTime;
    $wasSet = true;
    return $wasSet;
  }

  public function setTripDuration($aTripDuration)
  {
    $wasSet = false;
    $this->tripDuration = $aTripDuration;
    $wasSet = true;
    return $wasSet;
  }

  public function getDepartureTime()
  {
    return $this->departureTime;
  }

  public function getArrivalTime()
  {
    return $this->arrivalTime;
  }

  public function getTripDuration()
  {
    return $this->tripDuration;
  }

  public function getAvailableCabin_index($index)
  {
    $aAvailableCabin = $this->availableCabins[$index];
    return $aAvailableCabin;
  }

  public function getAvailableCabins()
  {
    $newAvailableCabins = $this->availableCabins;
    return $newAvailableCabins;
  }

  public function numberOfAvailableCabins()
  {
    $number = count($this->availableCabins);
    return $number;
  }

  public function hasAvailableCabins()
  {
    $has = $this->numberOfAvailableCabins() > 0;
    return $has;
  }

  public function indexOfAvailableCabin($aAvailableCabin)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->availableCabins as $availableCabin)
    {
      if ($availableCabin->equals($aAvailableCabin))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public function getDestination()
  {
    return $this->destination;
  }

  public static function minimumNumberOfAvailableCabins()
  {
    return 0;
  }

  public function addAvailableCabinVia($aCabinNumber, $aPrice)
  {
    return new Cabin($aCabinNumber, $aPrice, $this);
  }

  public function addAvailableCabin($aAvailableCabin)
  {
    $wasAdded = false;
    if ($this->indexOfAvailableCabin($aAvailableCabin) !== -1) { return false; }
    $existingTrip = $aAvailableCabin->getTrip();
    $isNewTrip = $existingTrip != null && $this !== $existingTrip;
    if ($isNewTrip)
    {
      $aAvailableCabin->setTrip($this);
    }
    else
    {
      $this->availableCabins[] = $aAvailableCabin;
    }
    $wasAdded = true;
    return $wasAdded;
  }

  public function removeAvailableCabin($aAvailableCabin)
  {
    $wasRemoved = false;
    //Unable to remove aAvailableCabin, as it must always have a trip
    if ($this !== $aAvailableCabin->getTrip())
    {
      unset($this->availableCabins[$this->indexOfAvailableCabin($aAvailableCabin)]);
      $this->availableCabins = array_values($this->availableCabins);
      $wasRemoved = true;
    }
    return $wasRemoved;
  }

  public function addAvailableCabinAt($aAvailableCabin, $index)
  {  
    $wasAdded = false;
    if($this->addAvailableCabin($aAvailableCabin))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfAvailableCabins()) { $index = $this->numberOfAvailableCabins() - 1; }
      array_splice($this->availableCabins, $this->indexOfAvailableCabin($aAvailableCabin), 1);
      array_splice($this->availableCabins, $index, 0, array($aAvailableCabin));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveAvailableCabinAt($aAvailableCabin, $index)
  {
    $wasAdded = false;
    if($this->indexOfAvailableCabin($aAvailableCabin) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfAvailableCabins()) { $index = $this->numberOfAvailableCabins() - 1; }
      array_splice($this->availableCabins, $this->indexOfAvailableCabin($aAvailableCabin), 1);
      array_splice($this->availableCabins, $index, 0, array($aAvailableCabin));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addAvailableCabinAt($aAvailableCabin, $index);
    }
    return $wasAdded;
  }

  public function setDestination($aDestination)
  {
    $wasSet = false;
    if ($aDestination == null)
    {
      return $wasSet;
    }
    
    $existingDestination = $this->destination;
    $this->destination = $aDestination;
    if ($existingDestination != null && $existingDestination != $aDestination)
    {
      $existingDestination->removeAvailableTrip($this);
    }
    $this->destination->addAvailableTrip($this);
    $wasSet = true;
    return $wasSet;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {
    foreach ($this->availableCabins as $aAvailableCabin)
    {
      $aAvailableCabin->delete();
    }
    $placeholderDestination = $this->destination;
    $this->destination = null;
    $placeholderDestination->removeAvailableTrip($this);
  }

}
?>