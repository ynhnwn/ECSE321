<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.24.0-d60c319 modeling language!*/

class TicketKiosk
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //TicketKiosk Associations
  private $destinations;
  private $transactions;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public function __construct()
  {
    $this->destinations = array();
    $this->transactions = array();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function getDestination_index($index)
  {
    $aDestination = $this->destinations[$index];
    return $aDestination;
  }

  public function getDestinations()
  {
    $newDestinations = $this->destinations;
    return $newDestinations;
  }

  public function numberOfDestinations()
  {
    $number = count($this->destinations);
    return $number;
  }

  public function hasDestinations()
  {
    $has = $this->numberOfDestinations() > 0;
    return $has;
  }

  public function indexOfDestination($aDestination)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->destinations as $destination)
    {
      if ($destination->equals($aDestination))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public function getTransaction_index($index)
  {
    $aTransaction = $this->transactions[$index];
    return $aTransaction;
  }

  public function getTransactions()
  {
    $newTransactions = $this->transactions;
    return $newTransactions;
  }

  public function numberOfTransactions()
  {
    $number = count($this->transactions);
    return $number;
  }

  public function hasTransactions()
  {
    $has = $this->numberOfTransactions() > 0;
    return $has;
  }

  public function indexOfTransaction($aTransaction)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->transactions as $transaction)
    {
      if ($transaction->equals($aTransaction))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public static function minimumNumberOfDestinations()
  {
    return 0;
  }

  public function addDestination($aDestination)
  {
    $wasAdded = false;
    if ($this->indexOfDestination($aDestination) !== -1) { return false; }
    $this->destinations[] = $aDestination;
    $wasAdded = true;
    return $wasAdded;
  }

  public function removeDestination($aDestination)
  {
    $wasRemoved = false;
    if ($this->indexOfDestination($aDestination) != -1)
    {
      unset($this->destinations[$this->indexOfDestination($aDestination)]);
      $this->destinations = array_values($this->destinations);
      $wasRemoved = true;
    }
    return $wasRemoved;
  }

  public function addDestinationAt($aDestination, $index)
  {  
    $wasAdded = false;
    if($this->addDestination($aDestination))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfDestinations()) { $index = $this->numberOfDestinations() - 1; }
      array_splice($this->destinations, $this->indexOfDestination($aDestination), 1);
      array_splice($this->destinations, $index, 0, array($aDestination));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveDestinationAt($aDestination, $index)
  {
    $wasAdded = false;
    if($this->indexOfDestination($aDestination) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfDestinations()) { $index = $this->numberOfDestinations() - 1; }
      array_splice($this->destinations, $this->indexOfDestination($aDestination), 1);
      array_splice($this->destinations, $index, 0, array($aDestination));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addDestinationAt($aDestination, $index);
    }
    return $wasAdded;
  }

  public static function minimumNumberOfTransactions()
  {
    return 0;
  }

  public function addTransaction($aTransaction)
  {
    $wasAdded = false;
    if ($this->indexOfTransaction($aTransaction) !== -1) { return false; }
    $this->transactions[] = $aTransaction;
    $wasAdded = true;
    return $wasAdded;
  }

  public function removeTransaction($aTransaction)
  {
    $wasRemoved = false;
    if ($this->indexOfTransaction($aTransaction) != -1)
    {
      unset($this->transactions[$this->indexOfTransaction($aTransaction)]);
      $this->transactions = array_values($this->transactions);
      $wasRemoved = true;
    }
    return $wasRemoved;
  }

  public function addTransactionAt($aTransaction, $index)
  {  
    $wasAdded = false;
    if($this->addTransaction($aTransaction))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfTransactions()) { $index = $this->numberOfTransactions() - 1; }
      array_splice($this->transactions, $this->indexOfTransaction($aTransaction), 1);
      array_splice($this->transactions, $index, 0, array($aTransaction));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveTransactionAt($aTransaction, $index)
  {
    $wasAdded = false;
    if($this->indexOfTransaction($aTransaction) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfTransactions()) { $index = $this->numberOfTransactions() - 1; }
      array_splice($this->transactions, $this->indexOfTransaction($aTransaction), 1);
      array_splice($this->transactions, $index, 0, array($aTransaction));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addTransactionAt($aTransaction, $index);
    }
    return $wasAdded;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {
    $this->destinations = array();
    $this->transactions = array();
  }

}
?>