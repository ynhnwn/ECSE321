<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.24.0-d60c319 modeling language!*/

class Cabin
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Cabin Attributes
  private $cabinNumber;
  private $price;

  //Cabin Associations
  private $trip;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public function __construct($aCabinNumber, $aPrice, $aTrip)
  {
    $this->cabinNumber = $aCabinNumber;
    $this->price = $aPrice;
    $didAddTrip = $this->setTrip($aTrip);
    if (!$didAddTrip)
    {
      throw new Exception("Unable to create availableCabin due to trip");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function setCabinNumber($aCabinNumber)
  {
    $wasSet = false;
    $this->cabinNumber = $aCabinNumber;
    $wasSet = true;
    return $wasSet;
  }

  public function setPrice($aPrice)
  {
    $wasSet = false;
    $this->price = $aPrice;
    $wasSet = true;
    return $wasSet;
  }

  public function getCabinNumber()
  {
    return $this->cabinNumber;
  }

  public function getPrice()
  {
    return $this->price;
  }

  public function getTrip()
  {
    return $this->trip;
  }

  public function setTrip($aTrip)
  {
    $wasSet = false;
    if ($aTrip == null)
    {
      return $wasSet;
    }
    
    $existingTrip = $this->trip;
    $this->trip = $aTrip;
    if ($existingTrip != null && $existingTrip != $aTrip)
    {
      $existingTrip->removeAvailableCabin($this);
    }
    $this->trip->addAvailableCabin($this);
    $wasSet = true;
    return $wasSet;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {
    $placeholderTrip = $this->trip;
    $this->trip = null;
    $placeholderTrip->removeAvailableCabin($this);
  }

}
?>