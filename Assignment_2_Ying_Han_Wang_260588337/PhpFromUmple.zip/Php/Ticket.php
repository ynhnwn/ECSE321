<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.24.0-d60c319 modeling language!*/

class Ticket
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Ticket Associations
  private $person;
  private $trip;
  private $cabin;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public function __construct($aPerson = null, $aTrip = null, $aCabin = null)
  {
    if (func_num_args() == 0) { return; }

    if ($aPerson == null || $aPerson->getTicket() != null)
    {
      throw new Exception("Unable to create Ticket due to aPerson");
    }
    $this->person = $aPerson;
    if (!$this->setTrip($aTrip))
    {
      throw new Exception("Unable to create Ticket due to aTrip");
    }
    if (!$this->setCabin($aCabin))
    {
      throw new Exception("Unable to create Ticket due to aCabin");
    }
  }
  public static function newInstance($aNameForPerson, $aTrip, $aCabin)
  {
    $thisInstance = new Ticket();
    $thisInstance->person = new Person($aNameForPerson, $thisInstance);
    $thisInstance->trip = new Trip(null);
    $thisInstance->cabin = new Cabin(null);
    return $thisInstance;
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function getPerson()
  {
    return $this->person;
  }

  public function getTrip()
  {
    return $this->trip;
  }

  public function getCabin()
  {
    return $this->cabin;
  }

  public function setTrip($aNewTrip)
  {
    $wasSet = false;
    if ($aNewTrip != null)
    {
      $this->trip = $aNewTrip;
      $wasSet = true;
    }
    return $wasSet;
  }

  public function setCabin($aNewCabin)
  {
    $wasSet = false;
    if ($aNewCabin != null)
    {
      $this->cabin = $aNewCabin;
      $wasSet = true;
    }
    return $wasSet;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {
    $existingPerson = $this->person;
    $this->person = null;
    if ($existingPerson != null)
    {
      $existingPerson->delete();
    }
    $this->trip = null;
    $this->cabin = null;
  }

}
?>