/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.24.0-d60c319 modeling language!*/

package ca.mcgill.ecse321.train.model;

// line 48 "../../../../../../../../ump/tmp269203/model.ump"
// line 113 "../../../../../../../../ump/tmp269203/model.ump"
public class Child extends Person
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Child(String aName, Ticket aTicket)
  {
    super(aName, aTicket);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {
    super.delete();
  }

}