/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.24.0-d60c319 modeling language!*/

package ca.mcgill.ecse321.train.model;

// line 70 "../../../../../../../../ump/tmp269203/model.ump"
// line 138 "../../../../../../../../ump/tmp269203/model.ump"
public class FirstClass extends Cabin
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public FirstClass(String aCabinNumber, double aPrice, Trip aTrip)
  {
    super(aCabinNumber, aPrice, aTrip);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {
    super.delete();
  }

}