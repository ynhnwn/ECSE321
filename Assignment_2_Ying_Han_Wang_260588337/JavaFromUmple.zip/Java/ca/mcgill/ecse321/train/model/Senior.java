/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.24.0-d60c319 modeling language!*/

package ca.mcgill.ecse321.train.model;

// line 52 "../../../../../../../../ump/tmp269203/model.ump"
// line 118 "../../../../../../../../ump/tmp269203/model.ump"
public class Senior extends Person
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Senior(String aName, Ticket aTicket)
  {
    super(aName, aTicket);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {
    super.delete();
  }

}